
### Overview is on the project's [homepage](http://r-datatable.com).
